<link href="https://cdn.jsdelivr.net/npm/alertifyjs@1.11.0/build/css/alertify.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.11.0/build/alertify.min.js"></script>

<?php
function AccesoLogin($user, $passw, $tabla, $campo)
{
    $consultas = new Procesos();
    $data = $consultas->getDataUser($user, $tabla, $campo);

    if ($data) {
        foreach ($data as $result) {
            echo $idusuario = $result['idusuario'];
            $usuario = $result['usuario'];
            $tipo = $result['tipo'];
            $estado = $result['estado'];
            $hash = $result['clave'];
        }

        if ($estado == 1) {
            if (password_verify($passw, $hash)) {
                $_SESSION["idusuario"] = $idusuario;
                $_SESSION["usuario"] = $usuario;
                $_SESSION["tipo"] = $tipo;

                $_SESSION["login_ok"] = 1;
                $_SESSION["tiempo"] = time();
                echo '<script>
                                $("#data").html("<div style=\'text-align:center;\'><img src=\'./public/img/login/load.gif\'   width=\'500px\' alt=\'loading\' /><br/><b style=\'color:white;\'>Un momento, por favor...</b></div>");
                                var msj = "<p style=\"color:black;\"><b>Bienvenido/a </b></p>";
                                alertify.success(msj);
                                setTimeout(function() {
                                    window.location.href = "index.php";
                                  }, 2000);
                            </script>';
            } else {
                echo '<script>
                                var msj = "Contraseña incorrecta...";
                                alertify.error(msj);
                                setTimeout(function() {
                                    window.location.href = "index.php";
                                  }, 1000);
                            </script>';
            }
        } else {
            echo '<script>
                            var msj = "El usuario no tiene permisos de acceso...";
                            alertify.error(msj);
                            setTimeout(function() {
                                window.location.href = "index.php";
                                }, 1000);
                        </script>';
        }
    } else {
        echo '<script>
                    var msj = "El usuario no existe....";
                    alertify.error(msj);
                    setTimeout(function() {
                        window.location.href = "index.php";
                        }, 1000);
                </script>';
    }
}

function CRUD($query, $tipo)
{
    $consultas = new Procesos();
    $data = $consultas->isdu($query, $tipo);
    return $data;
}

function buscavalor($tabla, $campo, $condicion)
{
    $valor = NULL;
    $consultas = new Procesos();
    $datos = $consultas->BuscaValor($tabla, $campo, $condicion);
    if ($datos) {
        foreach ($datos as $result) {
            $valor = $result[0];
        }
        return $valor;
    }
}

function MaxId($query)
{
    $consultas = new Procesos();
    $data = $consultas->max_id($query);
    return $data;
}

/* Funcion para cargar Imagenes*/
function CargaIMG($tmp_dir, $newName, $path)
{
    if (!is_dir($path)) {
        mkdir($path, 0777, true);
    }
    else{
        chmod($path.$newName, 0777);
    }

    if (is_uploaded_file($tmp_dir)) {
        copy($tmp_dir, $path . $newName);
        return true;
    } else {
        return false;
    }
}

function CountReg($query)
{
    $consultas = new Procesos();
    $data = $consultas->row_data($query);
    return $data;
}
?>