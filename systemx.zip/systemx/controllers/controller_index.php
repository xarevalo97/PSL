<?php

class Index
{

    public function base()
    {

        include "views/base.php";
    }
}
