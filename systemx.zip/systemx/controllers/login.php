<?php 
    @session_start();
    include '../models/conexion.php';
    include '../models/funciones.php';
    include '../controllers/funciones.php';
    
    if(isset($_POST['acclogin']))
    {
        $user = $_POST['user'];
        $passw = $_POST['passw'];
        $tabla = "usuarios";
        $campo = "usuario";
        AccesoLogin($user, $passw, $tabla,$campo);
    }
    else
    {
        header("Location: ../index.php");
    }
