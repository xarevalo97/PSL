$(document).ready(function () {
    // Panel de Solicitud de Incripciones Online
    /* Panel Usuarios */
    $(".panel-usuarios").click(function () {
        $("#contenido-principal").load("./views/modulos/usuarios/principal.php");
        return false;
    });
    /* Panel Instituciones */
    $(".panel-instituciones").click(function () {
        $("#contenido-principal").load("./views/modulos/instituciones/principal.php");
        return false;
    });
    /* Panel Instituciones */
    $(".panel-historial-gestiones").click(function () {
        $("#contenido-principal").load("./views/modulos/historial_gestiones/principal.php");
        return false;
    });
    /* Panel Clientes */
    $(".panel-clientes").click(function () {
        $("#contenido-principal").load("./views/modulos/clientes/principal.php");
        return false;
    });
    /* Panel Creditos */
    $(".panel-creditos").click(function () {
        $("#contenido-principal").load("./views/modulos/creditos/principal.php");
        return false;
    });
    /* Panel Tarjetas */
    $(".panel-tarjeta").click(function () {
        $("#contenido-principal").load("./views/modulos/tarjetas/principal.php");
        return false;
    });
    /* Panel Ayuda */
    $(".panel-ayuda").click(function () {
        $("#contenido-principal").load("./views/modulos/ayuda/principal.php");
        return false;
    });
    /* Panel Reportes */
    $(".panel-reportes").click(function () {
        $("#contenido-principal").load("./views/modulos/reportes/principal.php");
        return false;
    });

    /* Panel Cargos */
    $(".panel-cargos").click(function () {
        $("#contenido-principal").load("./views/modulos/cargos/principal.php");
        return false;
    });

    /* Editar Clave */
    $(".cambio-clave").click(function () {
        $("#ModalEditarClave").modal('show');
        return false;
    });

    /* Editar Perfil */
    $(".editar-perfil").click(function () {
        $("#ModalEditarPerfil").modal('show');
        return false;
    });

    /* Cerrar Sesión */
    $(".exit").click(function () {
        alertify.set("notifier", "position", "top-right");
        alertify.confirm('Cerrar Sesión', 'Seguro/a de cerrar sesión?', 
        function(){
            $("#data").load("./index.php?off=1");
            window.location.replace("./index.php");
        }, function(){ 
            alertify.error('<b>Cierre de sesión cancelado...</b>')
        });
    });

    /* Inputmask */
    $(".dui").inputmask("99999999-9");
});