$(document).ready(function () {
  /* Cerrar Sesión */
  $(".exit").click(function (event) {
    alertify.confirm(
      "SGI Cerrar Sesión",
      "Seguro/a de cerrar sesión",
      function () {
        alertify.set("notifier", "position", "top-right");
        alertify.success("Cerrado Sesión");

        $("#data").load("./index.php?off=1");
        window.location.replace("./index.php");
      },
      function () {
        alertify.set("notifier", "position", "top-right");
        alertify.error("Proceso Cancelado");
      }
    );
    event.preventDefault();
  });
});
