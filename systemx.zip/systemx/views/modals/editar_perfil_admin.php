<script>
  $(document).ready(function() {
    /* Actualizar Usuario y Empleado */
    $("#UpdateUserEmpleado").on("submit", function(e) {
      e.preventDefault();
      let idusuario, idcargo, tipo;
      idusuario = $("#idusuario").val();
      idcargo = $("#idcargo").val();
      tipo = $("#tipo").val();

      alertify.set('notifier', 'position', 'top-right');
      if (idcargo == null) {
        alertify.success("<b>Favor de seleccionar cargo....</b>");
      } else if (tipo == null) {
        alertify.success("<b>Favor de seleccionar tipo de usuario....</b>");
      } else {
        var formData = new FormData(document.getElementById("UpdateUserEmpleado"));

        formData.append("dato", "valor");

        $.ajax({
            url: "./views/modulos/usuarios/update.php",
            type: "post",
            dataType: "html",
            data: formData,
            cache: false,
            contentType: false,
            processData: false
          })
          .done(function(res) {
            $("#ModalEditarPerfilAdmin").modal('hide');
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();
            $("#principal-usuarios").html(res);
          });
      }
    });
  });
</script>
<form id="UpdateUserEmpleado">
  <div class="modal fade" id="ModalEditarPerfilAdmin" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Editar Perfil (Administrador)</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="DataEditarPerfilAdmin">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
          <button class="btn btn-primary">Actualizar</button>
        </div>
      </div>
    </div>
  </div>
</form>