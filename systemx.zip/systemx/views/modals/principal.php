<?php 
    include './views/modals/clave.php';
    include './views/modals/perfil.php';
    include './views/modals/editar_perfil_admin.php';
    include './views/modals/expedinte_empleado.php';
    include './views/modals/expediente_empleado.php';
    include './views/modals/registra_cliente.php';
    include './views/modals/editar_cliente.php';
    include './views/modals/expediente_cliente.php';
?>