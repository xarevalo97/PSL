<form id="SaveCliente">
  <div class="modal fade" id="ModalSaveCliente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><b>Registro de Cliente</b></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="DataSaveCliente">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
          <button class="btn btn-primary">Guardar</button>
        </div>
      </div>
    </div>
  </div>
</form>
<script>
  $(document).ready(function() {
    /* Actualizar Usuario y Empleado */
    $("#SaveCliente").on("submit", function(e) {
      e.preventDefault();
      let iddepartamento, idmunicipio, tipo_cliente;
      iddepartamento = $("#iddepartamento").val();
      idmunicipio = $("#idmunicipio").val();
      tipo_cliente = $("#tipo_cliente").val();

      alertify.set('notifier', 'position', 'top-right');
      if (iddepartamento == null) {
        alertify.success("<b>Favor de seleccionar departamento....</b>");
      } else if (idmunicipio == null) {
        alertify.success("<b>Favor de seleccionar municipio....</b>");
      } else if (tipo_cliente == null) {
        alertify.success("<b>Favor de seleccionar tipo de cliente....</b>");
      } else {
        var formData = new FormData(document.getElementById("SaveCliente"));

        formData.append("dato", "valor");

        $.ajax({
            url: "./views/modulos/clientes/insert.php",
            type: "post",
            dataType: "html",
            data: formData,
            cache: false,
            contentType: false,
            processData: false
          })
          .done(function(res) {
            $("#ModalSaveCliente").modal('hide');
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();
            $("#data-panel-clientes").html(res);
          });
      }
    });
  });
</script>