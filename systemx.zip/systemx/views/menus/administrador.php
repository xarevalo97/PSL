<div class="col-12 col-sm-3 col-xl-2 px-sm-2 px-0 bg-dark d-flex sticky-top">
    <div class="d-flex flex-sm-column flex-row flex-grow-1 align-items-center align-items-sm-start px-3 pt-2 text-danger active-hover">
        <a href="index.php" class="d-flex align-items-center pb-sm-3 mb-md-0 me-md-auto text-danger text-decoration-none ">
            <span class="d-none d-sm-inline fs-5">Sys &nbsp;</span> <span> CDSE</span>
        </a>
        <ul class="nav nav-pills flex-sm-column flex-row flex-nowrap flex-shrink-1 flex-sm-grow-0 flex-grow-1 mb-sm-auto mb-0 justify-content-center align-items-center align-items-sm-start" id="menu">
            <li class="nav-item">
                <a href="index.php" class="nav-link px-sm-0 px-2 text-danger">
                    <i class="fa-solid fa-display"></i> <span class="ms-1 d-none d-sm-inline">Inicio</span>
                </a>
            </li>
            <li>
                <a href="#" class="nav-link px-sm-0 px-2 text-danger panel-instituciones">
                    <i class="fa-solid fa-building-columns"></i> <span class="ms-1 d-none d-sm-inline">Instituciones</span>
                </a>
            </li>
            <li>
                <a href="#" class="nav-link px-sm-0 px-2 text-danger panel-historial-gestiones">
                    <i class="fa-solid fa-clock-rotate-left"></i> <span class="ms-1 d-none d-sm-inline">Historial Gestiones</span>
                </a>
            </li>
            <li>
                <a href="#" class="nav-link px-sm-0 px-2 text-danger panel-clientes">
                    <i class="fa-regular fa-circle-user "></i> <span class="ms-1 d-none d-sm-inline">Clientes</span>
                </a>
            </li>
            <li>
                <a href="#" class="nav-link px-sm-0 px-2 text-danger panel-creditos">
                    <i class="fa-solid fa-money-bill-transfer"></i> <span class="ms-1 d-none d-sm-inline">Creditos</span>
                </a>
            </li>
            <li>
                <a href="#" class="nav-link px-sm-0 px-2 text-danger panel-tarjeta">
                    <i class="fa-solid fa-credit-card"></i> <span class="ms-1 d-none d-sm-inline">Tarjetas de Credito</span>
                </a>
            </li>
            <li>
                <a href="#" class="nav-link px-sm-0 px-2 text-danger panel-ayuda">
                    <i class="fa-solid fa-circle-info"></i> <span class="ms-1 d-none d-sm-inline">Ayuda</span>
                </a>
            </li>
            <li>
                <a href="#" class="nav-link px-sm-0 px-2 text-danger panel-reportes">
                    <i class="fa-solid fa-file-pen"></i> <span class="ms-1 d-none d-sm-inline">Reportes</span></a>
            </li>
        </ul>
        <div class="dropdown py-sm-4 mt-sm-auto ms-auto ms-sm-0 flex-shrink-1">
            <a href="#" class="d-flex align-items-center text-danger text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                <?php
                @session_start();
                include './models/conexion.php';
                include './models/funciones.php';
                include './controllers/funciones.php';

                $usuario = $_SESSION["usuario"];
                $v_foto = buscavalor("empleados", "foto", "idusuario='" . $_SESSION["idusuario"] . "'");

                if (strlen($v_foto) != 0) {
                    $foto = $v_foto;
                } else {
                    $foto = "default.png";
                }
                ?>
                <img src="./public/img/empleados/<?php echo $foto;?>" alt="hugenerd" width="30" height="30" class="rounded-circle">
                <span class="d-none d-sm-inline mx-1"><b><?php echo $usuario; ?></b></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                <li>
                    <a class="dropdown-item cambio-clave text-danger" href="#"><i class="fa-solid fa-key"></i> <b>Cambiar Clave</b></a>
                </li>
                <li>
                    <a class="dropdown-item editar-perfil text-danger" href="#"><i class="fa-solid fa-clipboard-user"></i> <b>Perfil</b></a>
                </li>
                <li>
                    <hr class="dropdown-divider text-danger">
                </li>
                <li>
                    <a class="dropdown-item exit text-danger" href="#"><i class="fa-solid fa-right-from-bracket"></i> <b>Salir</b></a>
                </li>
            </ul>
        </div>
    </div>
</div>