<style>
    .contenedorVH {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .hijo {
        width:350px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }
</style>
<div class="contenedorVH">
    <div class="hijo">
        <div class="card" style="margin-top:100px;">
            <div class="card-header" style="vertical-align: middle;text-align:center;">
                <img class="card-img-top figure-img img-fluid rounded" src="./public/img/logo/logo1.png" width="100%" alt="">
            </div>
            <div class="card-body" style="background-color:#b71c1c;opacity:0.9;">

                <h4>
                    <p style="color: white;vertical-align: middle;text-align:center;">
                        <b>Iniciar Sesión</b>
                    </p>
                </h4>
                <form id="form-login">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                        <input type="text" class="form-control" name="user" placeholder="Usuario" required>
                    </div>
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1"><i class="fa-solid fa-key"></i></span>
                        <input type="password" name="passw" class="form-control" placeholder="Contraseña" required>
                    </div>
                    <input type="hidden" name="acclogin" value="1">
                    <div style="text-align: center;">
                        <button class="btn" style="background-color: #1b1b1b;color:white;"> <i class="fa-solid fa-unlock-keyhole"></i> <b>Ingresar</b></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        /* Verifica envio datos de Formulario Login*/
        $("#form-login").on("submit", function(e) {
            e.preventDefault();
            var formData = new FormData(document.getElementById("form-login"));

            formData.append("dato", "valor");
            $('#data').html('<div class="loading" style="margin-top:100px;text-align:center;"><img src="./public/img/login/load.gif" alt="loading" /><br/>Un momento, por favor...</div>');
            $.ajax({
                    url: "./controllers/login.php",
                    type: "post",
                    dataType: "html",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false
                })
                .done(function(res) {
                    $("#data").html(res);
                });
        });
    });
</script>