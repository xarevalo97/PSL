<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

?>
<div class="input-group mb-3" style="width:200px;">
    <span class="input-group-text" id="basic-addon1"><b>DUI:</b></span>
    <input type="text" class="form-control dui" id="dui-cliente" placeholder="N° DUI CLIENTE" required>
</div>
<hr>
<div id="data-cliente"></div>


<script>
    $(document).ready(function() {
        $(".dui").inputmask("99999999-9");

        /* Busca Información Cliente Para resgitrar Credito */
        $("#dui-cliente").on('keyup change', function() {
            let dui = $("#dui-cliente").val();
            $("#data-cliente").load("./views/modulos/creditos/data_cliente.php?dui=" + dui);
            return false;
        });
    });
</script>