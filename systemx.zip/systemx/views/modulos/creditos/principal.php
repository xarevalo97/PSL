<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/inputmask/inputmask.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/jquery.inputmask.bundle.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/css/inputmask.min.css" rel="stylesheet" />

<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';
date_default_timezone_set('America/El_Salvador');

$cont = 0;
?>

<div class="card" style="margin-bottom: 5px;">
    <div class="card-header bg-dark text-danger">
        <b>Panel Creditos</b>
    </div>
    <div class="card-body" id="data-panel-creditos">
        <div class="row">
            <div class="col-md-6">
                <a class="btn btn-primary" id="nuevo-credito"><i class="fa-solid fa-circle-plus"></i> <b>Credito</b></a>
            </div>
            <div class="col-md-6">
                <div class="input-group mb-3" style="width: 300px;float:right;">
                    <input type="text" class="form-control" name="valor" id="valor" placeholder="Busca Credito">
                    <button class="btn btn-success" id=""><i class="fa-solid fa-magnifying-glass"></i></button>
                    <button class="btn btn-primary" id="reload-panel"><i class="fa-solid fa-retweet"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        /* Registra Credito */
        $("#nuevo-credito").click(function(){
            $("#data-panel-creditos").load("views/modulos/creditos/add_credito.php");
            return false;
        });
    });
</script>