<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';
$dui = $_GET['dui'];

$datacliente = CRUD("SELECT * FROm clientes WHERE dui='$dui'", "s");

foreach ($datacliente as $result) {
    $idcliente = $result['idcliente'];
    $nit = $result['nit'];
    $nombres = $result['nombres'];
    $apellidos = $result['apellidos'];
    $email = $result['email'];
    $iddepartamento = $result['iddepartamento'];
    $idmunicipio = $result['idmunicipio'];
    $direccion1 = $result['direccion1'];
    $direccion2 = $result['direccion2'];
    $telefono = $result['telefono'];
    $trabaja = $result['trabaja'];
    $empresa_labora = $result['empresa_labora'];
    $cargo_laboral = $result['cargo_laboral'];
    $telefono_trabajo = $result['telefono_trabajo'];
    $ingresos = $result['ingresos'];
    $tipo_cliente = $result['tipo_cliente'];
    $estado = $result['estado'];
}
$tipo = ($tipo_cliente == "D") ? 'Deudor' : 'Fiador';
$departamento = buscavalor("departamentos", "departamento", "iddepartamento='$iddepartamento'");
$municipio = buscavalor("municipios", "municipio", "idmunicipio='$idmunicipio'");
$dataDepartamentos = CRUD("SELECT * FROM departamentos", "s");
?>

<div class="row">
    <div class="col-md-6">
        <p style="text-align: center;"><b>Datos Solicitante de Credito</b></p>
        <hr>
        <div class="input-group mb-3">
            <label><b>Código Cliente: </b><?php echo $idcliente; ?></label>
        </div>
        <div class="input-group mb-3">
            <label><b>Cliente: </b><?php echo $nombres . ' ' . $apellidos; ?></label>
        </div>
        <div class="input-group mb-3">
            <label><b>NIT: </b><?php echo $nit; ?></label>
        </div>
        <div class="input-group mb-3">
            <label><b>Email/Correo: </b><?php echo $email; ?></label>
        </div>
        <div class="input-group mb-3">
            <label><b>Teléfono: </b><?php echo $telefono; ?></label>
        </div>
        <div class="input-group mb-3">
            <label><b>Dirección: </b><?php echo $direccion1 . ', ' . $municipio . ', ' . $departamento; ?></label>
        </div>
        <hr>
        <div class="input-group mb-3">
            <label><b>Empresa: </b><?php echo $empresa_labora; ?></label>
        </div>
        <div class="input-group mb-3">
            <label><b>Dirección: </b><?php echo $direccion2; ?></label>
        </div>
        <div class="input-group mb-3">
            <label><b>Cargo: </b><?php echo $cargo_laboral; ?></label>
        </div>
        <div class="input-group mb-3">
            <label><b>Teléfono: </b><?php echo $telefono_trabajo; ?></label>
        </div>
        <div class="input-group mb-3">
            <label><b>Ingresos: </b>$<?php echo $ingresos; ?></label>
        </div>
    </div>
    <div class="col-md-6">
        <p style="text-align: center;"><b>Datos de Credito</b></p>
        <hr>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1"><b>N° Credito</b></span>
            <input type="text" class="form-control" name="idcredito" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1"><b>Tipo Credito</b></span>
            <input type="text" class="form-control" name="tipo_credito" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1"><b>Tipo Garantia</b></span>
            <input type="text" class="form-control" name="tipo_garantia" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1"><b>Monto a otorgar $</b></span>
            <input type="float" class="form-control" name="monto" id="monto" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1"><b>% Tasa Interes</b></span>
            <input type="float" class="form-control" name="tasa_interes" id="tasa_interes" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1"><b>Meses plazo de credito</b></span>
            <input type="text" class="form-control" name="plazo_credito_meses" min="0" value="0" id="plazo_credito_meses" placeholder="Reflejar plazo en meses" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1"><b>Fecha de otorgamiento</b></span>
            <input type="date" class="form-control" name="fecha_solicitud_credito" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1"><b>Valor Cuota $</b></span>
            <input type="text" class="form-control" name="valor_cuota" id="valor_cuota" readonly required>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        $("#plazo_credito_meses").on('keyup change',function(){
            let plazo, interes, monto, tinteres, tyear, cuota, cal1, cal2, cal3,cal4;
            plazo = parseInt($("#plazo_credito_meses").val());
            interes = parseFloat($("#tasa_interes").val());
            monto = parseFloat($("#monto").val());

            cal1 = (monto*(interes/100));
            tyear = (plazo/12);
            cal2 = (cal1*tyear);
            cal3 = monto + cal2;
            cal4 = cal3/plazo;
            $("#valor_cuota").val(cal4.toFixed(2));
            return false;
        });
    });
</script>