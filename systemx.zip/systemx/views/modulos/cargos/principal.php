<div class="card">
    <div class="card-header bg-dark text-danger">
        <b>Panel Cargos</b>
    </div>
    <div class="card-body">

    </div>
</div>