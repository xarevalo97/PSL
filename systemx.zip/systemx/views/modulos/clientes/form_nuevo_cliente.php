<!-- Inputmask -->
<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$dataDepartamentos = CRUD("SELECT * FROM departamentos", "s");
?>
<div class="row">
    <div class="col-4">
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">DUI</span>
            <input type="text" class="form-control dui" name="dui" required>
        </div>
        <div class="checbox">
            <input type="radio" name="tipoNIT" class="val-nit" value="N"> NIT Nuevo Formato &nbsp;/&nbsp;
            <input type="radio" name="tipoNIT" class="val-nit" value="A"> NIT Antiguo Formato
        </div>
        <div id="tipo-nit"></div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">Nombres</span>
            <input type="text" class="form-control" name="nombres" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">Apellidos</span>
            <input type="text" class="form-control" name="apellidos" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">Teléfono</span>
            <input type="text" class="form-control tel" name="telefono" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text">Email <br> Correo</span>
            <textarea class="form-control"  name="email" required></textarea>
        </div>
    </div>
    <div class="col-4">
        <div class="input-group mb-3">
            <label class="input-group-text" for="inputGroupSelect01">Departamento</label>
            <select class="form-select" name="iddepartamento" id="iddepartamento">
                <option disabled selected>Seleccione Departamento</option>
                <?php foreach ($dataDepartamentos as $result) : ?>
                    <option value="<?php echo $result['iddepartamento']; ?>"><?php echo $result['departamento']; ?></option>
                <?php endforeach ?>
            </select>
        </div>
        <div id="DataMunicipios"></div>
        <div class="input-group mb-3">
            <span class="input-group-text">Dirección 1</span>
            <textarea class="form-control" name="direccion1" required></textarea>
        </div>
        <div class="input-group mb-3 checbox">
            <input type="radio" name="trabaja" value="SI"> &nbsp;SI (Trabaja) &nbsp;/&nbsp;
            <input type="radio" name="trabaja" value="NO"> &nbsp;NO (Trabaja)
        </div>
    </div>
    <div class="col-4">
        
        <div class="input-group mb-3">
            <span class="input-group-text">Empresa</span>
            <textarea class="form-control" name="empresa_labora" placeholder="Empresa donde trabaja" required></textarea>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text">Dirección 2</span>
            <textarea class="form-control" name="direccion2" required></textarea>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text">Cargo</span>
            <textarea class="form-control" name="cargo_labora" placeholder="Cargo del que labora"></textarea>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">Teléfono</span>
            <input type="text" class="form-control tel" name="telefono_trabajo" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">Ingreso</span>
            <input type="text" class="form-control" name="ingresos" placeholder="$000.00" required>
        </div>
        <div class="input-group mb-3">
            <label class="input-group-text" for="inputGroupSelect01">Tipo Cliente</label>
            <select class="form-select" name="tipo_cliente" id="tipo_cliente">
                <option disabled selected>Seleccione Tipo</option>
                <option value="D">Deudor</option>
                <option value="F">Fiador</option>
            </select>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $(".dui").inputmask("99999999-9");
        $(".tel").inputmask("9999-9999");
        /* Muestra input segun el formato solicitado para el NIT */
        $('input:radio[name=tipoNIT]').click(function() {
            let valor = $('input:radio[name=tipoNIT]:checked').val();

            if (valor == "N") {
                $("#tipo-nit").load("./views/modulos/clientes/nit_nuevo.php");
            } else {
                $("#tipo-nit").load("./views/modulos/clientes/nit_antiguo.php");
            }
            return false;
        });

        /* Muestra Municipios Segun el Departaemnto Seleccionado */
        $("#iddepartamento").on('keyup change', function() {
            let iddepartamento = $("#iddepartamento").val();
            $("#DataMunicipios").load("./views/modulos/clientes/select_municipios.php?iddepartamento=" + iddepartamento);
            return false;
        });
    });
</script>