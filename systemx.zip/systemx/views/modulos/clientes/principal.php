<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/inputmask/inputmask.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/jquery.inputmask.bundle.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/css/inputmask.min.css" rel="stylesheet" />
<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';
date_default_timezone_set('America/El_Salvador');

$cont = 0;

if (isset($_GET['num'])) {
    $pagina = $_GET["num"]; // la variable de la pagina
} else {
    $pagina = 0;
}

if (isset($_GET['n_reg']) || isset($_GET['num'])) {
    $registros = $_GET['num_reg'];
} else {
    $registros = 1;
}

if (!$pagina) {
    $inicio = 0;
    $pagina = 1;
} else {
    $inicio = ($pagina - 1) * $registros;
}

if (isset($_POST['valor'])) {
    $valor = $_POST['valor'];

    $query = "SELECT * FROM clientes WHERE nombres LIKE '%$valor%' || apellidos LIKE '%$valor%' || dui LIKE '%$valor%'";

    $dataclientes = CRUD("SELECT * FROM clientes WHERE nombres LIKE '%$valor%' || apellidos LIKE '%$valor%' || dui LIKE '%$valor%'", "s");
} else {
    $query = "SELECT * FROM clientes";

    $dataclientes = CRUD("SELECT * FROM clientes ORDER BY dui ASC LIMIT $inicio,$registros", "s");
}


$num_registro = CountReg($query);

$paginas = ceil($num_registro / $registros);
?>
<div class="card">
    <div class="card-header bg-dark text-danger">
        <b>Panel Clientes Deudores/Fiadores</b>
    </div>
    <div class="card-body" id="data-panel-clientes">
        <div class="row">
            <div class="col-md-6">
                <a class="btn btn-primary add-clientes-fiadores"><i class="fa-solid fa-circle-plus"></i> <b>Cliente</b></a>
            </div>
            <div class="col-md-6">
                <div class="input-group mb-3" style="width: 300px;float:right;">
                    <input type="text" class="form-control" name="valor" id="valor" placeholder="Busca Cliente ó Fiador">
                    <button class="btn btn-success" id="search-cliente"><i class="fa-solid fa-magnifying-glass"></i></button>
                    <button class="btn btn-primary" id="reload-panel"><i class="fa-solid fa-retweet"></i></button>
                </div>
            </div>
        </div>
        <?php if ($dataclientes) : ?>
            <table class="table table-hover table-boordeless table-bo">
                <thead style="vertical-align: middle;text-align:center;" class="bg-dark text-white">
                    <tr>
                        <th>N°</th>
                        <th>DUI</th>
                        <th>Cliente</th>
                        <th>Tipo <br>Cliente</th>
                        <th colspan="3">Acciones</th>
                    </tr>
                </thead>
                <tbody style="vertical-align: middle;text-align:center;">
                    <?php foreach ($dataclientes as $result) : ?>
                        <?php
                        $idcliente = $result['idcliente'];
                        $dui = $result['dui'];
                        $nombres = $result['nombres'];
                        $apellidos = $result['apellidos'];
                        $tipo = ($result['tipo_cliente'] == "D") ? 'Deudor' : 'Fiador';
                        ?>
                        <tr>
                            <td><?php echo $cont += 1; ?></td>
                            <td><?php echo $dui; ?></td>
                            <td><?php echo $nombres . ' ' . $apellidos; ?></td>
                            <td><?php echo $tipo; ?></td>
                            <td>
                                <a href="" class="btn btn-primary ficha-cliente" idcliente ="<?php echo $idcliente ; ?>"><i class="fa-solid fa-address-card"></i></a>
                            </td>
                            <td>
                                <a href="" class="btn btn-success editar-cliente" idcliente ="<?php echo $idcliente ; ?>"><i class="fa-solid fa-user-pen"></i></a>
                            </td>
                            <td>
                                <a href="" class="btn btn-danger eliminar-cliente" idcliente ="<?php echo $idcliente ; ?>"><i class="fa-solid fa-user-xmark"></i></a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
            <div>
                <?php if ($num_registro > $registros) : ?>
                    <?php if ($pagina == 1) : ?>
                        <div style="text-align: center;">
                            <a class="btn btn-primary btn-sm pagina bloquear-boton" href="" v-num="<?php echo ($pagina - 1); ?>" num-reg="<?php echo $registros; ?>"> <i class="fa-solid fa-square-caret-left fa-2x"></i> </a> &nbsp;
                            <a class="btn btn-primary btn-sm pagina" href="" v-num="<?php echo ($pagina + 1); ?>" num-reg="<?php echo $registros; ?>"> <i class="fa-solid fa-square-caret-right fa-2x"></i></a>
                        </div>
                    <?php elseif ($pagina == $paginas) : ?>
                        <div style="text-align: center;">
                            <a class="btn btn-primary btn-sm pagina" href="" v-num="<?php echo ($pagina - 1); ?>" num-reg="<?php echo $registros; ?>"> <i class="fa-solid fa-square-caret-left fa-2x"></i> </a>&nbsp;
                            <a class="btn btn-primary btn-sm pagina bloquear-boton" href="" v-num="<?php echo ($pagina + 1); ?>" num-reg="<?php echo $registros; ?>"> <i class="fa-solid fa-square-caret-right fa-2x"></i></a>

                        </div>
                    <?php else : ?>
                        <div style="text-align: center;">
                            <a class="btn btn-primary btn-sm pagina" href="" v-num="<?php echo ($pagina - 1); ?>" num-reg="<?php echo $registros; ?>"> <i class="fa-solid fa-square-caret-left fa-2x"></i> </a> &nbsp;
                            <a class="btn btn-primary btn-sm pagina" href="" v-num="<?php echo ($pagina + 1); ?>" num-reg="<?php echo $registros; ?>"> <i class="fa-solid fa-square-caret-right fa-2x"></i></a>
                        </div>
                    <?php endif ?>
                <?php endif ?>
                <div class="alert alert-info" style="font-weight: bold;text-align:center;margin-top:15px;">
                    <?php echo "P&aacute;gina: " . $pagina . ' / ' . $paginas; ?>
                </div>
            <?php else : ?>
                <div class="alert alert-success"><b>No se encuentran clientes registrados...</b></div>
            <?php endif ?>
            </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        /* Modal Registra Cliente */
        $(".add-clientes-fiadores").click(function() {
            $("#ModalSaveCliente").modal('show');
            $("#DataSaveCliente").load("./views/modulos/clientes/form_nuevo_cliente.php");
            return false;
        });

        /* Modal Editar Cliente  */
        $(".editar-cliente").click(function() {
            let idcliente = $(this).attr('idcliente');
            $("#ModalUpdateCliente").modal('show');
            $("#DataUpdateCliente").load("./views/modulos/clientes/form_editar_cliente.php?idcliente=" + idcliente);
            return false;
        });

        /* Modal Ficha/Expediente Cliente  */
        $(".ficha-cliente").click(function() {
            let idcliente = $(this).attr('idcliente');
            $("#ModalFichaCliente").modal('show');
            $("#DataFichaCliente").load("./views/modulos/clientes/ficha_cliente.php?idcliente=" + idcliente);
            return false;
        });

        /*Envía el número de pagina */
        $("a.pagina").click(function(event) {
            var num, reg, ciclo;
            num = $(this).attr("v-num");
            reg = $(this).attr("num-reg");
            $("#contenido-principal").load("./views/modulos/clientes/principal.php?num=" + num + "&num_reg=" + reg);
            return false;
        });

        /*Busca Cliente */
        $('#search-cliente').click(function(event) {
            let valor1 = $("#valor").val();

            if (valor1 == "" || valor1 == null) {
                
            } else {
                $.ajax({
                    type: "POST",
                    url: "./views/modulos/clientes/principal.php",
                    data: {
                        valor: valor1
                    },
                    success: function(datos) {
                        $("#contenido-principal").html(datos);
                    }
                });
            }
           
            return false;
        });

        /*Recarga pagina*/
        $('#reload-panel').click(function(event) {
            $("#contenido-principal").load("./views/modulos/clientes/principal.php");
        });

        /* Eliminar Cliente */
        $(".eliminar-cliente").click(function(){
            let idcliente = $(this).attr('idcliente');
            alertify.confirm('Eliminar Cliente', 'Seguro/a de eliminar cliente?', 
            function(){ 
                 
            }, function(){ 
                alertify.error('<b>Proceso Cancelado.....</b>')
            });
            return false;
        });
        
    });
</script>