<div class="input-group mb-3">
    <span class="input-group-text" id="basic-addon1">NIT</span>
    <input type="text" class="form-control NIT-A" name="nit" required>
</div>
<script>
    $(document).ready(function() {
        $(".NIT-A").inputmask("9999-999999-999-9");
    });
</script>