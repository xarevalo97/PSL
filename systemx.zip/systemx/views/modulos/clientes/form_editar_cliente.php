<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$idcliente = $_GET['idcliente'];

$datacliente = CRUD("SELECT * FROm clientes WHERE idcliente='$idcliente'", "s");

foreach ($datacliente as $result) {
    $dui = $result['dui'];
    $nit = $result['nit'];
    $nombres = $result['nombres'];
    $apellidos = $result['apellidos'];
    $email = $result['email'];
    $iddepartamento = $result['iddepartamento'];
    $idmunicipio = $result['idmunicipio'];
    $direccion1 = $result['direccion1'];
    $direccion2 = $result['direccion2'];
    $telefono = $result['telefono'];
    $trabaja = $result['trabaja'];
    $empresa_labora = $result['empresa_labora'];
    $cargo_laboral = $result['cargo_laboral'];
    $telefono_trabajo = $result['telefono_trabajo'];
    $ingresos = $result['ingresos'];
    $tipo_cliente = $result['tipo_cliente'];
    $estado = $result['estado'];
}
$tipo = ($tipo_cliente == "D") ? 'Deudor' : 'Fiador';
$departamento = buscavalor("departamentos", "departamento", "iddepartamento='$iddepartamento'");
$municipio = buscavalor("municipios", "municipio", "idmunicipio='$idmunicipio'");
$dataDepartamentos = CRUD("SELECT * FROM departamentos", "s");
?>

<input type="hidden" name="idcliente" value="<?php echo $idcliente;?>">
<div class="row">
    <div class="col-4">
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">DUI</span>
            <input type="text" class="form-control dui" name="dui" value="<?php echo $dui; ?>" required>
        </div>
        <div class="checbox">
            <input type="radio" name="tipoNIT" class="val-nit" value="N"> NIT Nuevo Formato &nbsp;/&nbsp;
            <input type="radio" name="tipoNIT" class="val-nit" value="A"> NIT Antiguo Formato
        </div>
        <div id="tipo-nit">
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">NIT</span>
                <input type="text" class="form-control" name="nit" value="<?php echo $nit; ?>" required>
            </div>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">Nombres</span>
            <input type="text" class="form-control" name="nombres" value="<?php echo $nombres; ?>" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">Apellidos</span>
            <input type="text" class="form-control" name="apellidos" value="<?php echo $apellidos; ?>" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">Teléfono</span>
            <input type="text" class="form-control tel" name="telefono" value="<?php echo $telefono; ?>" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text">Email <br> Correo</span>
            <textarea class="form-control"  name="email" required><?php echo $email; ?></textarea>
        </div>
    </div>
    <div class="col-4">
        <div class="input-group mb-3">
            <label class="input-group-text" for="inputGroupSelect01">Departamento</label>
            <select class="form-select" name="iddepartamento" id="iddepartamento">
                <option value="<?php echo $iddepartamento; ?>" selected><?php echo $departamento; ?></option>
                <?php foreach ($dataDepartamentos as $result) : ?>
                    <option value="<?php echo $result['iddepartamento']; ?>"><?php echo $result['departamento']; ?></option>
                <?php endforeach ?>
            </select>
        </div>
        <div id="DataMunicipios">
            <input type="hidden" class="form-control" name="idmunicipio" id="idmunicipio" value="<?php echo $idmunicipio; ?>">
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Municipio</span>
                <input type="text" class="form-control" value="<?php echo $municipio; ?>" required>
            </div>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text">Dirección 1</span>
            <textarea class="form-control" name="direccion1" required><?php echo $direccion1; ?></textarea>
        </div>
        <div class="input-group mb-3 checbox">
            <?php if ($trabaja == "SI") : ?>
                <input type="radio" name="trabaja" value="SI" checked> &nbsp;SI (Trabaja) &nbsp;/&nbsp;
                <input type="radio" name="trabaja" value="NO"> &nbsp;NO (Trabaja)
            <?php else : ?>
                <input type="radio" name="trabaja" value="SI"> &nbsp;SI (Trabaja) &nbsp;/&nbsp;
                <input type="radio" name="trabaja" value="NO" checked> &nbsp;NO (Trabaja)
            <?php endif ?>

        </div>
    </div>
    <div class="col-4">

        <div class="input-group mb-3">
            <span class="input-group-text">Empresa</span>
            <textarea class="form-control" name="empresa_labora" placeholder="Empresa donde trabaja" required><?php echo $empresa_labora; ?></textarea>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text">Dirección 2</span>
            <textarea class="form-control" name="direccion2" required><?php echo $direccion2; ?></textarea>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text">Cargo</span>
            <textarea class="form-control" name="cargo_labora" placeholder="Cargo del que labora"><?php echo $cargo_laboral; ?></textarea>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">Teléfono</span>
            <input type="text" class="form-control tel" name="telefono_trabajo" value="<?php echo $telefono_trabajo; ?>" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">Ingreso</span>
            <input type="text" class="form-control" name="ingresos" placeholder="$000.00" value="<?php echo $ingresos; ?>" required>
        </div>
        <div class="input-group mb-3">
            <label class="input-group-text" for="inputGroupSelect01">Tipo Cliente</label>
            <select class="form-select" name="tipo_cliente" id="tipo_cliente">
                <option value="<?php echo $tipo_cliente; ?>" selected><?php echo $tipo; ?></option>
                <?php if ($tipo_cliente == "D") : ?>
                    <option value="F">Fiador</option>
                <?php else : ?>
                    <option value="D">Deudor</option>
                <?php endif ?>
            </select>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $(".dui").inputmask("99999999-9");
        $(".tel").inputmask("9999-9999");
        /* Muestra input segun el formato solicitado para el NIT */
        $('input:radio[name=tipoNIT]').click(function() {
            let valor = $('input:radio[name=tipoNIT]:checked').val();

            if (valor == "N") {
                $("#tipo-nit").load("./views/modulos/clientes/nit_nuevo.php");
            } else {
                $("#tipo-nit").load("./views/modulos/clientes/nit_antiguo.php");
            }
            return false;
        });

        /* Muestra Municipios Segun el Departaemnto Seleccionado */
        $("#iddepartamento").on('keyup change', function() {
            let iddepartamento = $("#iddepartamento").val();
            $("#DataMunicipios").load("./views/modulos/clientes/select_municipios.php?iddepartamento=" + iddepartamento);
            return false;
        });
    });
</script>