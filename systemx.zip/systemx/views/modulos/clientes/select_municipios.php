<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$iddepartamento = $_GET['iddepartamento'];

$dataMunicipios = CRUD("SELECT * FROM municipios WHERE iddepartamento='$iddepartamento'", "s");
?>
<div class="input-group mb-3">
    <label class="input-group-text" for="inputGroupSelect01">Municipio</label>
    <select class="form-select" name="idmunicipio" id="idmunicipio">
        <option disabled selected>Seleccione Municipio</option>
        <?php foreach ($dataMunicipios as $result) : ?>
            <option value="<?php echo $result['idmunicipio']; ?>"><?php echo $result['municipio']; ?></option>
        <?php endforeach ?>
    </select>
</div>