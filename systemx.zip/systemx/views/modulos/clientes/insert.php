<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$dui = $_POST['dui'];
$nit = $_POST['nit'];
$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$email = $result['email'];
$iddepartamento = $_POST['iddepartamento'];
$idmunicipio = $_POST['idmunicipio'];
$direccion1 = $_POST['direccion1'];
$direccion2 = $_POST['direccion2'];
$telefono = $_POST['telefono'];
$trabaja = $_POST['trabaja'];
$empresa_labora = $_POST['empresa_labora'];
$cargo_laboral = $_POST['cargo_labora'];
$telefono_trabajo = $_POST['telefono_trabajo'];
$ingresos = $_POST['ingresos'];
$tipo_cliente = $_POST['tipo_cliente'];

$tabla = "clientes";
$campos = "dui, nit, nombres, apellidos, email, iddepartamento, idmunicipio, direccion1, direccion2, telefono, trabaja, empresa_labora, cargo_laboral, telefono_trabajo, ingresos, tipo_cliente";
$valores = "'$dui', '$nit', '$nombres', '$apellidos', '$email', '$iddepartamento', '$idmunicipio', '$direccion1', '$direccion2', '$telefono', '$trabaja', '$empresa_labora', '$cargo_laboral', '$telefono_trabajo', '$ingresos', '$tipo_cliente'";

$insert = CRUD("INSERT INTO $tabla($campos) VALUES($valores)", "i");

?>


<?php if ($insert) : ?>
    <script>
        $(document).ready(function() {
            alertify.success("<b>Cliente registrado....</b>");
            $("#contenido-principal").load("./views/modulos/clientes/principal.php");
            return false;
        });
    </script>
<?php else : ?>
    <script>
        $(document).ready(function() {
            alertify.error("<b>Error cliente no registrado....</b>");
            $("#contenido-principal").load("./views/modulos/clientes/principal.php");
            return false;
        });
    </script>
<?php endif ?>