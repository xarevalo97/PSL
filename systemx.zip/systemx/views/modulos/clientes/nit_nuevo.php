<div class="input-group mb-3">
    <span class="input-group-text" id="basic-addon1">NIT</span>
    <input type="text" class="form-control NIT-N" name="nit" required>
</div>

<script>
    $(document).ready(function() {
        $(".NIT-N").inputmask("99999999-9");
    });
</script>