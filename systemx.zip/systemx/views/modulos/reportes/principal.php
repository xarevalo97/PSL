<div class="card">
    <div class="card-header bg-dark text-danger">
        <b>Panel Reportes</b>
    </div>
    <div class="card-body">

    </div>
</div>