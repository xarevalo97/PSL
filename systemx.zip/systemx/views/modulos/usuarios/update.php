<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$idempleado = $_POST['idempleado'];
$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$dui = $_POST['dui'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];
$correo = $_POST['correo'];

$idusuario = $_POST['idusuario'];
$usuario = $_POST['usuario'];

if (isset($_POST['clave'])) {
    $clave = password_hash($_POST['clave'], PASSWORD_DEFAULT);

    $campos0 = "usuario='$usuario', clave='$clave', tipo='$tipo'";
} else {
    $campos0 = "usuario='$usuario', tipo='$tipo'";
}
$tipo = $_POST['tipo'];

$idcargo = $_POST['idcargo'];

// Obtenemos los atributos de la fotografia
$imgFile = $_FILES['foto']['name'];
$tmp_dir = $_FILES['foto']['tmp_name'];
$imgSize = $_FILES['foto']['size'];

if ($imgSize != 0) {
    $path = "../../../public/img/empleados/";
    $imgExt = strtolower(pathinfo($imgFile, PATHINFO_EXTENSION)); //Obtenemos la extencion del archivo
    $newName = $idusuario . "." . $imgExt; //Asignamos un nuevo nombre al archivo

    $carga_img = CargaIMG($tmp_dir, $newName, $path);

    switch ($carga_img) {
        case 0;
            echo '<script>
                    alertify.set("notifier","position", "top-right");
                    alertify.error("Error datos e Imagen no actualizados...");
                    $("#ModalEditarPerfilAdmin").modal("hide");
                    $("#contenido-principal").load("./views/modulos/usuarios/principal.php");
                </script>';
            break;
        case 1;

            $tabla0 = "usuarios";
            $condicion0 = "idusuario = '$idusuario'";
            $insert0 = CRUD("UPDATE $tabla0 SET $campos0 WHERE $condicion0", "u");

            $tabla1 = "empleados";
            $campos1 = "nombres='$nombres', apellidos='$apellidos', dui='$dui', direccion='$direccion', telefono='$telefono', correo='$correo', idcargo='$idcargo', foto='$newName'";
            $condicion1 = "idusuario='$idusuario'";
            $insert1 = CRUD("UPDATE $tabla1 SET $campos1 WHERE $condicion1", "u");

            echo '<script>
                alertify.set("notifier","position", "top-right");
                alertify.success("<b>Datos modificados...</b>"); 
                $("#ModalEditarPerfilAdmin").modal("hide");
                $("#contenido-principal").load("./views/modulos/usuarios/principal.php");
            </script>';
            break;
    }
} else {
    $tabla0 = "usuarios";
    
    $condicion0 = "idusuario = '$idusuario'";

    $insert0 = CRUD("UPDATE $tabla0 SET $campos0 WHERE $condicion0", "u");

    $tabla1 = "empleados";
    $campos1 = "nombres='$nombres', apellidos='$apellidos', dui='$dui', direccion='$direccion', telefono='$telefono', correo='$correo', idcargo='$idcargo'";
    $condicion1 = "idempleado='$idempleado' AND idusuario='$idusuario'";

    $insert1 = CRUD("UPDATE $tabla1 SET $campos1 WHERE $condicion1", "u");

    echo '<script>
        alertify.set("notifier","position", "top-right");
        alertify.success("<b>Datos modificados...</b>"); 
        $("#ModalEditarPerfilAdmin").modal("hide");
        $("#contenido-principal").load("./views/modulos/usuarios/principal.php");
    </script>';
}
