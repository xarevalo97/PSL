<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$dataUsuarios = CRUD("SELECT * FROM usuarios WHERE idusuario NOT IN (SELECT idusuario FROM empleados)", "s");
?>

<div class="input-group mb-3" style="width: 350px;">
    <label class="input-group-text" for="inputGroupSelect01"><b>Usuario</b></label>
    <select class="form-select" name="idusuario" id="idusuario">
        <option selected>Seleccione Usuario</option>
        <?php foreach($dataUsuarios AS $result):?>
            <option value="<?php echo $result['idusuario'];?>"><?php echo $result['usuario'];?></option>
        <?php endforeach?>
    </select>
</div>