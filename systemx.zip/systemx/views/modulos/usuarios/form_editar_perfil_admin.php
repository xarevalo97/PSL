<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$idusuario = $_GET['idusuario'];

$dataEmpleado = CRUD("SELECT * FROM empleados AS e INNER JOIN usuarios AS u ON u.idusuario=e.idusuario WHERE e.idusuario='$idusuario'", "s");

foreach ($dataEmpleado as $result) {
    $idempleado = $result['idempleado'];
    $nombres = $result['nombres'];
    $apellidos = $result['apellidos'];
    $dui = $result['dui'];
    $telefono = $result['telefono'];
    $direccion = $result['direccion'];
    $correo = $result['correo'];
    $idcargo = $result['idcargo'];
    $usuario = $result['usuario'];
    $idtipo = $result['tipo'];
    $clave = $result['clave'];
}
$cargo = buscavalor("cargos", "cargo", "idcargo='$idcargo'");
$tipo = buscavalor("tipo_usuario", "tipo", "idtipo='$idtipo'");

$dataCargos = CRUD("SELECT * FROM cargos WHERE idcargo != '$idcargo'", "s");
$dataTipoUsuario = CRUD("SELECT * FROM tipo_usuario WHERE idtipo != '$idtipo'", "s");

?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/inputmask/inputmask.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/jquery.inputmask.bundle.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/css/inputmask.min.css" rel="stylesheet" />
<script>
    $(document).ready(function() {
        $(".dui").inputmask("99999999-9");
        $(".tel").inputmask("9999-9999");
        // Funcion para pre-visualizar imagen antes de guardar Productos
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    // Asignamos el atributo src a la tag de imagen
                    $('#imagenmuestra').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        // El listener va asignado al input
        $("#foto").change(function() {
            readURL(this);
        });
    });
</script>
<input type="hidden" name="idempleado" value="<?php echo $idempleado; ?>">
<div class="row">
    <div class="col-md-6" style="margin: 0 auto;">
        <div class="input-group mb-3" style="width: 350px;">
            <span class="input-group-text" id="basic-addon1"><b>Nombres</b></span>
            <input type="text" class="form-control" name="nombres" value="<?php echo $nombres; ?>" required>
        </div>
        <div class="input-group mb-3" style="width: 350px;">
            <span class="input-group-text" id="basic-addon1"><b>Apellido</b></span>
            <input type="text" class="form-control" name="apellidos" value="<?php echo $apellidos; ?>" required>
        </div>
        <div class="input-group mb-3" style="width: 350px;">
            <span class="input-group-text" id="basic-addon1"><b>DUI</b></span>
            <input type="text" class="form-control dui" name="dui" value="<?php echo $dui; ?>" required>
        </div>
        <div class="input-group mb-3" style="width: 350px;">
            <span class="input-group-text" id="basic-addon1"><b>Teléfono</b></span>
            <input type="text" class="form-control tel" name="telefono" value="<?php echo $telefono; ?>" required>
        </div>
        <div class="input-group mb-3" style="width: 350px;">
            <span class="input-group-text"><b>Dirección:</b></span>
            <textarea class="form-control" name="direccion" required><?php echo $direccion; ?></textarea>
        </div>
        <div class="input-group mb-3">
            <label class="input-group-text" for="inputGroupFile01">Fotografia</label>
            <input type="file" class="form-control" name="foto" id="foto">
        </div>
        <div>
            <img src="" width="150px" alt="" id="imagenmuestra">
        </div>
    </div>
    <div class="col-md-6">
        <div class="input-group mb-3" style="width: 350px;">
            <span class="input-group-text"><b>Email:</b></span>
            <textarea class="form-control" name="correo" required><?php echo $correo; ?></textarea>
        </div>

        <div class="input-group mb-3" style="width: 350px;">
            <span class="input-group-text" id="basic-addon1"><b>Código Usuario</b></span>
            <input type="text" class="form-control" name="idusuario" value="<?php echo $idusuario; ?>" readonly>
        </div>
        <div class="input-group mb-3" style="width: 350px;">
            <span class="input-group-text" id="basic-addon1"><b>Usuario</b></span>
            <input type="text" class="form-control" name="usuario" value="<?php echo $usuario; ?>" required>
        </div>
        <div class="input-group mb-3" style="width: 350px;">
            <span class="input-group-text" id="basic-addon1"><b>Contraseña</b></span>
            <input type="text" class="form-control" name="clave">
            <input type="hidden" class="form-control" name="old_clave" value="<?php echo $clave; ?>">
        </div>

        <div class="input-group mb-3" style="width: 350px;">
            <label class="input-group-text" for="inputGroupSelect01"><b>Cargo</b></label>
            <select class="form-select" name="idcargo" id="idcargo">
                <option value="<?php echo $idcargo; ?>" selected><?php echo $cargo; ?></option>
                <?php foreach ($dataCargos as $result) : ?>
                    <option value="<?php echo $result['idcargo']; ?>"><?php echo $result['cargo']; ?></option>
                <?php endforeach ?>
            </select>
        </div>
        <div class="input-group mb-3" style="width: 350px;">
            <label class="input-group-text" for="inputGroupSelect01"><b>Tipo Usuario</b></label>
            <select class="form-select" name="tipo" id="tipo">
                <option value="<?php echo $idtipo; ?>" selected><?php echo $tipo; ?></option>
                <?php foreach ($dataTipoUsuario as $result) : ?>
                    <option value="<?php echo $result['idtipo']; ?>"><?php echo $result['tipo']; ?></option>
                <?php endforeach ?>
            </select>
        </div>
    </div>
</div>