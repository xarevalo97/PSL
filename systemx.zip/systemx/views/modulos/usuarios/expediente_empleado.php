<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$idusuario = $_GET['idusuario'];

$dataEmpleado = CRUD("SELECT * FROM empleados AS e INNER JOIN usuarios AS u ON u.idusuario=e.idusuario WHERE e.idusuario='$idusuario'", "s");

foreach ($dataEmpleado as $result) {
    $idempleado = $result['idempleado'];
    $nombres = $result['nombres'];
    $apellidos = $result['apellidos'];
    $dui = $result['dui'];
    $telefono = $result['telefono'];
    $direccion = $result['direccion'];
    $correo = $result['correo'];
    $idcargo = $result['idcargo'];
    $usuario = $result['usuario'];
    $idtipo = $result['tipo'];
    $clave = $result['clave'];
    $foto = $result['foto'];
}
$cargo = buscavalor("cargos", "cargo", "idcargo='$idcargo'");
$tipo = buscavalor("tipo_usuario", "tipo", "idtipo='$idtipo'");

?>

<div id="muestra">
    <table class="table table-hover table-bordered table-borderless table-sm" style="font-size:12px;width:80%;margin: 0 auto;" border="1">
        <thead style="vertical-align:middle;text-align:center;background-color:#003d33;color:white;">
            <tr>
                <th>Foto</th>
                <th>Empleado</th>
                <th colspan="2">Datos Generales</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="width: 100px;vertical-align:middle;text-align:center;">
                    <img src="./public/img/empleados/<?php echo $foto; ?>" width="100px" alt="">
                </td>
                <td style="width: 150px;">
                    <p><label><b>Nombres:</b> <?php echo $nombres; ?></label></p>
                    <p><label><b>Apellidos:</b> <?php echo $apellidos; ?></label></p>
                </td>
                <td style="width: 150px;">
                    <p><label><b>Dirección:</b> <?php echo $direccion; ?></label></p>
                </td>
                <td>
                    <p><label><b>Teléfono:</b> <?php echo $telefono; ?></label></p>
                    <p><label><b>DUI:</b> <?php echo $dui; ?></label></p>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<script>
    function imprim2() {
        var titulo = "Expediente Empleado <?php echo $nombres.' '.$apellidos;?>";
        var mywindow = window.open('', 'PRINT', 'height=600,width=800');
        mywindow.document.write('<html><head><title>' + titulo + '</title>');
        mywindow.document.write('<style> body{margin: 20mm 5mm 20mm 5mm; font-size:12px;font-family: "Roboto Condensed", sans-serif !important;} table {border-collapse: collapse;font-size:12px;}</style>');
        mywindow.document.write('</head><body >');
        mywindow.document.write(document.getElementById('muestra').innerHTML);
        mywindow.document.write('</body></html>');
        mywindow.document.close(); // necesario para IE >= 10
        mywindow.focus(); // necesario para IE >= 10
        mywindow.print();
        mywindow.close();

        return true;
    }
</script>