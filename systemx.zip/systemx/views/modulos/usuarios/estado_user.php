<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$usuario = $_GET['usuario'];

$busca_usuario = buscavalor("usuarios","COUNT(usuario)","usuario LIKE '%$usuario%'");
?>
<?php if($busca_usuario != 0):?>
    <div class="alert alert-danger" style="width: 350px;"><b>Usuario ya en uso intente con uno nuevo...</b></div>
<?php else:?>
    <div class="alert alert-success" style="width: 350px;"><b>Usuario disponible...</b></div>
<?php endif ?>
