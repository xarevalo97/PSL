<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$idusuario = $_GET['idusuario'];
$valor = $_GET['valor'];

$tabla0 = "usuarios";
$campos0 = "estado='$valor'";
$condicion0 = "idusuario = '$idusuario'";

$update0 = CRUD("UPDATE $tabla0 SET $campos0 WHERE $condicion0", "u");

if ($valor == 1) {
    echo '<script>
        alertify.set("notifier","position", "top-right");
        alertify.success("<b>Usuario Habilitado</b>");
        $("#contenido-principal").load("./views/modulos/usuarios/principal.php");
    </script>';
} else {
    echo '<script>
        alertify.set("notifier","position", "top-right");
        alertify.error("<b>Usuario Deshabilitado...</b>");
        $("#contenido-principal").load("./views/modulos/usuarios/principal.php");
    </script>';
}
