<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$maxidusuario = MaxId("SELECT MAX(idusuario) FROM usuarios") + 1;

?>
<div class="input-group mb-3" style="width: 350px;">
    <span class="input-group-text" id="basic-addon1"><b>Código Usuario</b></span>
    <input type="text" class="form-control" name="idusuario" value="<?php echo $maxidusuario; ?>" readonly>
</div>
<div class="input-group mb-3" style="width: 350px;">
    <span class="input-group-text" id="basic-addon1"><b>Usuario</b></span>
    <input type="text" class="form-control" name="usuario" id="estado-usuario" required>
</div>
<div id="estado-user"></div>
<div class="input-group mb-3" style="width: 350px;">
    <span class="input-group-text" id="basic-addon1"><b>Contraseña</b></span>
    <input type="text" class="form-control" name="clave" required>
</div>


<script>
    $(document).ready(function() {
        $("#estado-usuario").on('keyup change', function() {
            let usuario = $("#estado-usuario").val();
            $("#estado-user").load("./views/modulos/usuarios/estado_user.php?usuario=" + usuario);
            return false;
        });
    });
</script>