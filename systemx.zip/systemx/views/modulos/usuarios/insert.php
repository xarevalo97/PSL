<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$dui = $_POST['dui'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];
$correo = $_POST['correo'];

$idusuario = $_POST['idusuario'];

$idcargo = $_POST['idcargo'];


if (isset($_POST['usuario'])) {
    $usuario = $_POST['usuario'];
    $clave = password_hash($_POST['clave'], PASSWORD_DEFAULT);
    $tipo = $_POST['tipo'];

    $tabla0 = "usuarios";
    $campos0 = "idusuario, usuario, clave, tipo, estado";
    $valores0 = "'$idusuario', '$usuario', '$clave', '$tipo', 1";

    $insert0 = CRUD("INSERT INTO $tabla0 ($campos0) VALUES($valores0)", "i");

    if ($insert0) {

        $tabla1 = "empleados";
        $campos1 = "nombres, apellidos, dui, direccion, telefono, correo, idusuario, idcargo";
        $valores1 = "'$nombres', '$apellidos', '$dui', '$direccion', '$telefono', '$correo', '$idusuario', '$idcargo'";

        $insert1 = CRUD("INSERT INTO $tabla1 ($campos1) VALUES($valores1)", "i");

        if ($insert1) {
            echo '<script>
                    alertify.set("notifier","position", "top-right");
                    alertify.success("<b>Usuario y perfil de empleado registrado...</b>");
                    $("#contenido-principal").load("./views/modulos/usuarios/principal.php");
                </script>';
        } else {
            echo '<script>
                    alertify.set("notifier","position", "top-right");
                    alertify.error("<b>Error al registrar perfil de empleado...</b>");
                    $("#principal-usuarios").load("./views/modulos/usuarios/form_nuevo_usuario.php");
                </script>';
        }
    } else {
        echo '<script>
                alertify.set("notifier","position", "top-right");
                alertify.error("<b>Error al registrar usuario...</b>");
                $("#principal-usuarios").load("./views/modulos/usuarios/form_nuevo_usuario.php");
            </script>';
    }
} else {

    $tabla1 = "empleados";
    $campos1 = "nombres, apellidos, dui, direccion, telefono, correo, idusuario, idcargo";
    $valores1 = "'$nombres', '$apellidos', '$dui', '$direccion', '$telefono', '$correo', '$idusuario', '$idcargo'";

    $insert1 = CRUD("INSERT INTO $tabla1 ($campos1) VALUES($valores1)", "i");

    if ($insert1) {
        echo '<script>
                alertify.set("notifier","position", "top-right");
                alertify.success("<b>Usuario y perfil de empleado registrado...</b>");
                $("#contenido-principal").load("./views/modulos/usuarios/principal.php");
            </script>';
    } else {
        echo '<script>
                alertify.set("notifier","position", "top-right");
                alertify.error("<b>Error al registrar perfil de empleado...</b>");
                $("#principal-usuarios").load("./views/modulos/usuarios/form_nuevo_usuario.php");
            </script>';
    }
}
