<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$dataCargos = CRUD("SELECT * FROM cargos", "s");
$dataTipoUsuario = CRUD("SELECT * FROM tipo_usuario","s");
?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/inputmask/inputmask.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/jquery.inputmask.bundle.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/css/inputmask.min.css" rel="stylesheet" />
<script>
    $(document).ready(function() {
        $(".dui").inputmask("99999999-9");
        $(".tel").inputmask("9999-9999");

        /* Recarga de pagina */
        $(".add-user").click(function() {
            $("#principal-usuarios").load("./views/modulos/usuarios/form_nuevo_usuario.php");
            return false;
        });

        /* Asignar Usuario */
        $(".asig-user").click(function() {
            let valor = $('input:radio[name=val_user]:checked').val();

            if (valor == 1) {
                $("#data-user").load("./views/modulos/usuarios/new_user.php");
            } else {
                $("#data-user").load("./views/modulos/usuarios/old_user.php");
            }
            return false
        });

        /* Registrar Usuario y Empleado */
        $("#SaveUserEmpleado").on("submit", function(e) {
            e.preventDefault();
            let idusuario, idcargo, tipo;
            idusuario = $("#idusuario").val();
            idcargo = $("#idcargo").val();
            tipo = $("#tipo").val();

            alertify.set('notifier', 'position', 'top-right');
            if (idcargo == null) {
                alertify.success("<b>Favor de seleccionar cargo....</b>");
            }else if (tipo == null) {
                alertify.success("<b>Favor de seleccionar tipo de usuario....</b>");
            } else {
                var formData = new FormData(document.getElementById("SaveUserEmpleado"));

                formData.append("dato", "valor");

                $.ajax({
                        url: "./views/modulos/usuarios/insert.php",
                        type: "post",
                        dataType: "html",
                        data: formData,
                        cache: false,
                        contentType: false,
                        processData: false
                    })
                    .done(function(res) {
                        $("#principal-usuarios").html(res);
                    });
            }
        });
    });
</script>
<div style="margin-bottom: 10px;">
    <a href="" class="btn btn-success add-user"><i class="fa-solid fa-rotate"></i></a>
</div>
<form id="SaveUserEmpleado">
    <div class="row">
        <div class="col-md-6" style="margin: 0 auto;">
            <div class="input-group mb-3" style="width: 350px;">
                <span class="input-group-text" id="basic-addon1"><b>Nombres</b></span>
                <input type="text" class="form-control" name="nombres" required>
            </div>
            <div class="input-group mb-3" style="width: 350px;">
                <span class="input-group-text" id="basic-addon1"><b>Apellido</b></span>
                <input type="text" class="form-control" name="apellidos" required>
            </div>
            <div class="input-group mb-3" style="width: 350px;">
                <span class="input-group-text" id="basic-addon1"><b>DUI</b></span>
                <input type="text" class="form-control dui" name="dui" required>
            </div>
            <div class="input-group mb-3" style="width: 350px;">
                <span class="input-group-text" id="basic-addon1"><b>Teléfono</b></span>
                <input type="text" class="form-control tel" name="telefono" required>
            </div>
            <div class="input-group mb-3" style="width: 350px;">
                <span class="input-group-text"><b>Dirección:</b></span>
                <textarea class="form-control" name="direccion" required></textarea>
            </div>
        </div>
        <div class="col-md-6">
            <div class="input-group mb-3" style="width: 350px;">
                <span class="input-group-text"><b>Email:</b></span>
                <textarea class="form-control" name="correo" required></textarea>
            </div>

            <div class="checkbox">
                <p><label><input type="radio" class="asig-user" value="1" name="val_user"> Asignar Nuevo Usuario </label></p>
                <p><label><input type="radio" class="asig-user" value="2" name="val_user"> Asignar Usuario ya registrado</label></p>
            </div>
            <div id="data-user"></div>

            <div class="input-group mb-3" style="width: 350px;">
                <label class="input-group-text" for="inputGroupSelect01"><b>Cargo</b></label>
                <select class="form-select" name="idcargo" id="idcargo">
                    <option disabled selected>Seleccione Cargo</option>
                    <?php foreach ($dataCargos as $result) : ?>
                        <option value="<?php echo $result['idcargo']; ?>"><?php echo $result['cargo']; ?></option>
                    <?php endforeach ?>
                </select>
            </div>
            <div class="input-group mb-3" style="width: 350px;">
                <label class="input-group-text" for="inputGroupSelect01"><b>Tipo Usuario</b></label>
                <select class="form-select" name="tipo" id="tipo">
                    <option disabled selected>Seleccione Tipo Usuario</option>
                    <?php foreach ($dataTipoUsuario as $result) : ?>
                        <option value="<?php echo $result['idtipo']; ?>"><?php echo $result['tipo']; ?></option>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
    </div>
    <button class="btn btn-primary">Guardar</button>
</form>