<?php
@session_start();
include '../../../models/conexion.php';
include '../../../models/funciones.php';
include '../../../controllers/funciones.php';

$dataUsuarios = CRUD("SELECT * FROM usuarios", "s");
$contUsers = 0;
?>
<script>
    $(document).ready(function() {
        /* Agregar Usuario y Datos empleado */
        $(".add-user").click(function() {
            $("#principal-usuarios").load("./views/modulos/usuarios/form_nuevo_usuario.php");
            return false;
        });

        /* Editar Estado Usuario */
        $(".estado-user").click(function() {
            let valor, idusuario;
            valor = $(this).attr("valor");
            idusuario = $(this).attr("idusuario");
            $("#principal-usuarios").load("./views/modulos/usuarios/estado_usuario.php?valor=" + valor + "&idusuario=" + idusuario);
            return false;
        });

        /* Editar Perfil Admin*/
        $(".editar-perfil-admin").click(function() {
            let idusuario = $(this).attr("idusuario");
            $("#ModalEditarPerfilAdmin").modal('show');
            $("#DataEditarPerfilAdmin").load("./views/modulos/usuarios/form_editar_perfil_admin.php?idusuario=" + idusuario);
            return false;
        });

        /* Ver Expediente Empleado*/
        $(".expediente-empleado").click(function() {
            let idusuario = $(this).attr("idusuario");
            $("#ModalExpedienteEMpleado").modal('show');
            $("#DataExpedienteEMpleado").load("./views/modulos/usuarios/expediente_empleado.php?idusuario=" + idusuario);
            return false;
        });
    });
</script>
<div class="card">
    <div class="card-header bg-dark text-danger">
        <b>Panel Usuarios</b>
    </div>
    <div class="card-body" id="principal-usuarios">
        <div style="margin-bottom:5px;">
            <a href="" class="btn btn-primary add-user"><i class="fa-solid fa-user-plus"></i></a>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover table-borderless">
                <thead class="bg-dark text-white" style="vertical-align: middle;text-align:center;">
                    <tr>
                        <th>N°</th>
                        <th>ID</th>
                        <th>Usuario</th>
                        <th>Empleado</th>
                        <th>Cargo</th>
                        <th>Expediente</th>
                        <th colspan="2">Acciones</th>
                    </tr>
                </thead>
                <tbody style="vertical-align: middle;text-align:center;">
                    <?php foreach ($dataUsuarios as $result) : ?>
                        <?php
                        $busca_usuario = buscavalor("empleados", "COUNT(idusuario)", "idusuario='" . $result['idusuario'] . "'");
                        ?>
                        <tr>
                            <td><?php echo $contUsers += 1; ?></td>
                            <td><?php echo $result['idusuario']; ?></td>
                            <td><?php echo $result['usuario']; ?></td>
                            <td>
                                <?php
                                $empleado = buscavalor("empleados", "CONCAT(nombres,' ',apellidos)", "idusuario='" . $result['idusuario'] . "'");
                                echo (strlen($empleado) == 0) ? 'Sin perfil registrado' : $empleado;
                                ?>
                            </td>
                            <td>
                                <?php
                                $idcargo = buscavalor("empleados", "idcargo", "idusuario='" . $result['idusuario'] . "'");
                                $cargo = buscavalor("cargos", "cargo", "idcargo='$idcargo'");
                                echo (strlen($cargo) == 0) ? 'Sin cargo registrado' : $cargo;
                                ?>
                            </td>
                            <td>
                                <?php if ($busca_usuario != 0) : ?>
                                    <a href="" class="btn btn-primary expediente-empleado" idusuario="<?php echo $result['idusuario']; ?>"><i class="fa-solid fa-folder-open"></i></a>
                                <?php else : ?>
                                    <a href="" class="btn btn-primary bloquear-boton"><i class="fa-solid fa-folder-open"></i></a>
                                <?php endif ?>
                            </td>
                            <td>
                                <?php if ($busca_usuario != 0) : ?>
                                    <?php if ($result['estado']) : ?>
                                        <a href="" class="btn btn-danger estado-user" valor="0" idusuario="<?php echo $result['idusuario']; ?>">
                                            <i class="fa-solid fa-user-slash"></i>
                                        </a>
                                    <?php else : ?>
                                        <a href="" class="btn btn-primary estado-user" valor="1" idusuario="<?php echo $result['idusuario']; ?>"><i class="fa-solid fa-user-check"></i></a>
                                    <?php endif ?>
                                <?php else : ?>
                                    <?php if ($result['estado']) : ?>
                                        <a href="" class="btn btn-danger estado-user bloquear-boton" valor="0" idusuario="<?php echo $result['idusuario']; ?>">
                                            <i class="fa-solid fa-user-slash"></i>
                                        </a>
                                    <?php else : ?>
                                        <a href="" class="btn btn-primary estado-user bloquear-boton" valor="1" idusuario="<?php echo $result['idusuario']; ?>"><i class="fa-solid fa-user-check"></i></a>
                                    <?php endif ?>
                                <?php endif ?>
                            </td>
                            <td>
                                <?php if ($busca_usuario != 0) : ?>
                                    <a href="" class="btn btn-success editar-perfil-admin" idusuario="<?php echo $result['idusuario']; ?>">
                                        <i class="fa-solid fa-user-pen"></i>
                                    </a>
                                <?php else : ?>
                                    <a href="" class="btn btn-success editar-perfil-admin bloquear-boton" idusuario="<?php echo $result['idusuario']; ?>">
                                        <i class="fa-solid fa-user-pen"></i>
                                    </a>
                                <?php endif ?>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</div>