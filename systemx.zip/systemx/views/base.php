<?php
if (isset($_GET['off'])) {
    session_start();
    $_SESSION = array();
    session_destroy();
    echo '<script> window.location.replace("./index.php");<script>';
} else {
    @session_start();
}
error_reporting(0);
date_default_timezone_set('America/El_Salvador');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Last-Modified" content="0">
    <meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./public/img/logo/logo1.png">
    <?php if (isset($_SESSION['login_ok'])) : ?>
        <title>SYS CDSE</title>
    <?php else : ?>
        <title>Login (SYS CDSE)</title>
    <?php endif ?>
    <!-- CDN Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

    <!-- JS -->
    <script src="./public/js/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">

    <!-- FontAwesome -->
    <script src="./public/js/FontAwesome_bfc7c963fc.js"></script>

    <!-- Funciones de procesos de carag dinamica -->
    <script src="./public/js/funciones.js"></script>

    <!-- alertify -->
    <script src="./public/js/alertify.min.js"></script>
    <link rel="stylesheet" href="./public/css/alertify.min.css">
    <link rel="stylesheet" href="./public/css/default.min.css">
    <link rel="stylesheet" href="./public/css/alertify.min.css">
    <link rel="stylesheet" href="./public/css/default.min.css">

    <!-- Inputmask -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/inputmask/inputmask.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/jquery.inputmask.bundle.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/css/inputmask.min.css" rel="stylesheet" />

    <!-- fonts.googleapis -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300&display=swap" rel="stylesheet">

    <!-- DataTables-->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/jq-3.6.0/dt-1.12.1/datatables.min.css" />
    <script src="https://cdn.datatables.net/v/bs5/jq-3.6.0/dt-1.12.1/datatables.min.js"></script>

    <script src=//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js></script>
    <script src=//cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js></script>
    <script src=//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js></script>
    <script src=//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js></script>
    <script src=//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js></script>
    <script src=//cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js></script>
    <script src=//cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js></script>

  

    <style>
        body {
            font-family: 'Roboto Condensed', sans-serif !important;
        }

        @media (max-width: 576px) {
            .h-sm-100 {
                height: 93vh;
            }

            /*
            body{
                background-color: red !important;
            }*/
            .tp {
                position: relative;
            }
        }

        .active-hover :hover {
            color: white !important;
        }

        .bloquear-boton {
            pointer-events: none;
            cursor: default;
            background-color: gray;
            color: white;
        }
    </style>
</head>

<body style="background-color: #424242;" id="data">
    <?php if (isset($_SESSION['login_ok'])) :
    ?>
        <div class="container-fluid overflow-hidden tp">
            <div class="row vh-100 overflow-auto tp">
                <?php if ($_SESSION["tipo"] == 1) : ?>
                    <?php include './views/menus/root.php'; ?>
                <?php elseif ($_SESSION["tipo"] == 2) : ?>
                    <?php include './views/menus/administrador.php'; ?>
                <?php elseif ($_SESSION["tipo"] == 3) : ?>
                    <?php include './views/menus/operador.php'; ?>
                <?php endif ?>
                <div class="col d-flex flex-column h-sm-100 tp">
                    <main class="row overflow-auto tp">
                        <div class="col pt-4" id="contenido-principal">
                            <div class="card">
                                <div class="card-header bg-dark text-danger">
                                    <b>Panel Principal</b>
                                </div>
                                <div class="card-body">
                                    <div style="vertical-align: middle;text-align:center;">
                                        <p style="text-align: center;">
                                        <h2><b>Bienvenido/a</b></h2>
                                        </p>
                                        <img src="./public/img/logo/logo1.png" width="50%" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                    <footer class="row bg-light py-3 mt-auto bg-dark tp">
                        <div class="col"><img src="./public/img/otros/cc.webp" width="100px" alt=""></div>
                    </footer>
                </div>
            </div>
        </div>
    <?php else : ?>
        <?php include './views/login.php'; ?>
    <?php endif ?>
    <?php include './views/modals/principal.php'; ?>
</body>

</html>