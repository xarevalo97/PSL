<?php
include "./controllers/controller_index.php";
$mvc = new Index();
$mvc->base();
